'use strict';
/* Next Pro Institute — zero-dependency Node server (Node 18+). Made by ARS Cloud. */
const http=require('http'),fs=require('fs'),path=require('path'),crypto=require('crypto');
const PORT=process.env.PORT||3000,ROOT=path.join(__dirname,'public'),DD=path.join(__dirname,'data'),DBF=path.join(DD,'db.json');
const MIME={'.html':'text/html; charset=utf-8','.css':'text/css; charset=utf-8','.js':'application/javascript; charset=utf-8','.json':'application/json','.png':'image/png','.jpg':'image/jpeg','.jpeg':'image/jpeg','.svg':'image/svg+xml','.ico':'image/x-icon','.webp':'image/webp','.woff2':'font/woff2'};
const hash=pw=>{const s=crypto.randomBytes(16).toString('hex');return s+':'+crypto.scryptSync(String(pw),s,32).toString('hex')};
const check=(pw,h)=>{if(!h)return false;const[s,k]=h.split(':'),a=Buffer.from(k,'hex'),b=crypto.scryptSync(String(pw),s,32);return a.length===b.length&&crypto.timingSafeEqual(a,b)};
const today=()=>new Date().toISOString().slice(0,10),pad=n=>('000'+n).slice(-4);
const str=(v,n)=>String(v==null?'':v).trim().slice(0,n||200),slug=s=>String(s).toLowerCase().replace(/[^a-z0-9]+/g,'-').replace(/^-|-$/g,'');
const safeUrl=u=>/^https?:\/\//i.test(u)?u:'';
let db;
function persist(){const t=DBF+'.tmp';fs.writeFileSync(t,JSON.stringify(db));fs.renameSync(t,DBF)}
function addLog(m){db.log.unshift({t:new Date().toLocaleString(),m});db.log=db.log.slice(0,200)}
function init(){fs.mkdirSync(DD,{recursive:true});
 if(fs.existsSync(DBF)){db=JSON.parse(fs.readFileSync(DBF,'utf8'));return}
 const pw=process.env.ADMIN_PASSWORD||crypto.randomBytes(6).toString('base64url');
 db={rev:1,adminPw:hash(pw),seq:{stu:0,cert:0,app:100,cls:0},info:{name:'Next Pro Institute',phone:'',email:'',whatsapp:'',facebook:'',address:''},
  apps:[],stu:[],pay:[],cert:[],cls:[],msg:[],ins:[],log:[],
  crs:[['Digital Marketing','3 months',8000],['Artificial Intelligence','2 months',6000],['Professional Video Editing','3 months',9000],['Combo Course','6 months',18000]].map(a=>({n:a[0],dur:a[1],fee:a[2],s:'active'}))};
 addLog('System ready');persist();
 console.log('\n  FIRST RUN — Admin login:  username: admin   password: '+pw+'\n  (change it in Admin → Settings)\n')}
const tokens=new Map(),hits=new Map();
const mk=(role,id)=>{const t=crypto.randomBytes(24).toString('hex');tokens.set(t,{role,id,exp:Date.now()+(role==='admin'?8:12)*36e5});return t};
const tokOf=req=>{const h=req.headers.authorization||'';return h.startsWith('Bearer ')?h.slice(7):''};
const auth=(req,role)=>{const x=tokens.get(tokOf(req));return x&&x.exp>Date.now()&&x.role===role?x:null};
function limited(req,key,max,win){const ip=((process.env.TRUST_PROXY&&req.headers['x-forwarded-for'])||'').split(',')[0].trim()||req.socket.remoteAddress,k=key+ip,n=Date.now(),h=(hits.get(k)||[]).filter(t=>n-t<win);h.push(n);hits.set(k,h);return h.length>max}
setInterval(()=>{const n=Date.now();for(const[k,v]of hits)if(!v.some(t=>n-t<36e5))hits.delete(k);for(const[k,v]of tokens)if(v.exp<n)tokens.delete(k)},6e5).unref();
const body=(req,max)=>new Promise((res,rej)=>{let n=0;const c=[];req.on('data',d=>{n+=d.length;if(n>max){rej(new Error('big'));req.destroy()}else c.push(d)});req.on('end',()=>{try{res(JSON.parse(Buffer.concat(c).toString()||'{}'))}catch(e){rej(e)}});req.on('error',rej)});
const send=(res,code,o)=>{res.writeHead(code,{'Content-Type':'application/json; charset=utf-8','Cache-Control':'no-store'});res.end(JSON.stringify(o))};
const clean=()=>{const o=JSON.parse(JSON.stringify(db));delete o.adminPw;delete o.rev;o.stu.forEach(s=>delete s.pwh);return o};
const KEYS=['apps','stu','pay','cert','cls','msg','ins','log','crs'];
async function api(req,res,u){const p=u.pathname,m=req.method,q=u.searchParams;
 if(m==='GET'&&p==='/api/public')return send(res,200,{info:db.info,ins:db.ins});
 if(m==='POST'&&(p==='/api/apply'||p==='/api/contact')){
  if(limited(req,'f',15,6e5))return send(res,429,{});const b=await body(req,20e3);if(b.bot)return send(res,200,{ok:1});
  const n=str(b.name,100);
  if(p==='/api/apply'){const ph=str(b.phone,30);if(!n||!ph||!b.consent)return send(res,400,{});
   const cr=db.crs.find(c=>slug(c.n)===str(b.course,80))||db.crs[0]||{n:''};
   db.apps.unshift({id:'APP-'+(++db.seq.app),n,ph,email:str(b.email,120),c:cr.n,dob:str(b.dob,20),father:str(b.father,100),mother:str(b.mother,100),addr:str(b.address,300),pub:!!b.consent_public,d:today(),s:'pending'});addLog('New application: '+n)}
  else{const t=str(b.message,2000),e=str(b.contact,120);if(!n||!t||!e)return send(res,400,{});db.msg.unshift({id:'M'+Date.now().toString(36),n,e,t,read:false,d:today(),src:'contact'});addLog('New message from '+n)}
  db.rev++;persist();return send(res,200,{ok:1})}
 if(m==='GET'&&p==='/api/verify'){if(limited(req,'v',30,6e5))return send(res,429,{});
  const c=str(q.get('c'),60).toUpperCase(),r=str(q.get('r'),60).toUpperCase(),ce=db.cert.find(x=>String(x.no).toUpperCase()===c),st=ce&&db.stu.find(s=>s.id===ce.sid);
  if(!ce||!st||String(st.r).toUpperCase()!==r)return send(res,200,{found:false});
  return send(res,200,{found:true,status:ce.s,no:ce.no,reg:st.r,course:ce.c,name:st.pub?st.n:null})}
 /* student */
 if(m==='POST'&&p==='/api/student/login'){if(limited(req,'l',10,6e5))return send(res,429,{});const b=await body(req,2e3),reg=str(b.reg,60).toUpperCase(),st=db.stu.find(s=>String(s.r).toUpperCase()===reg);
  if(!st||st.s!=='active'||!check(b.pw,st.pwh))return send(res,401,{});return send(res,200,{token:mk('student',st.id)})}
 if(p.startsWith('/api/student/')){const x=auth(req,'student'),st=x&&db.stu.find(s=>s.id===x.id);if(!st||st.s!=='active')return send(res,401,{});
  if(m==='GET'&&p==='/api/student/me'){const py=db.pay.find(a=>a.sid===st.id);
   return send(res,200,{st:{n:st.n,id:st.id,r:st.r,c:st.c,ph:st.ph||'',email:st.email||'',d:st.d||''},pay:py?{fee:py.fee,paid:py.paid}:null,
    certs:db.cert.filter(c=>c.sid===st.id).map(c=>({no:c.no,c:c.c,s:c.s})),
    classes:db.cls.filter(c=>{const t=String(c.to);return t==='All students'||t==='Course: '+st.c||(t.startsWith('Student: ')&&t.slice(9).split(' · ')[0]===st.id)}).map(c=>({title:c.title,at:c.at,url:safeUrl(c.url),note:c.note||''}))})}
  if(m==='POST'&&p==='/api/student/correction'){if(limited(req,'c',10,36e5))return send(res,429,{});const t=str((await body(req,5e3)).text,1500);if(!t)return send(res,400,{});
   db.msg.unshift({id:'M'+Date.now().toString(36),n:st.n,e:st.r,t:'[Correction request] '+t,read:false,d:today(),src:'student'});db.rev++;persist();return send(res,200,{ok:1})}}
 /* admin */
 if(m==='POST'&&p==='/api/admin/login'){if(limited(req,'a',8,6e5))return send(res,429,{});const b=await body(req,2e3);
  if(b.u==='admin'&&check(b.p,db.adminPw))return send(res,200,{token:mk('admin','admin')});return send(res,401,{})}
 if(p.startsWith('/api/admin/')){if(!auth(req,'admin'))return send(res,401,{});
  if(m==='POST'&&p==='/api/admin/logout'){tokens.delete(tokOf(req));return send(res,200,{})}
  if(m==='GET'&&p==='/api/admin/db'){if(q.get('since')==String(db.rev))return send(res,200,{rev:db.rev});return send(res,200,{rev:db.rev,db:clean()})}
  if(m==='PUT'&&p==='/api/admin/db'){const b=await body(req,8e6),d=b.db;if(!d||b.rev!==db.rev)return send(res,409,{});
   if(KEYS.some(k=>!Array.isArray(d[k]))||typeof d.seq!=='object'||typeof d.info!=='object')return send(res,400,{});
   const old=new Map(db.stu.map(s=>[s.id,s.pwh])),n={rev:db.rev+1,adminPw:db.adminPw,seq:{stu:+d.seq.stu||0,cert:+d.seq.cert||0,app:+d.seq.app||100,cls:+d.seq.cls||0},info:d.info};
   KEYS.forEach(k=>n[k]=d[k]);n.log=n.log.slice(0,200);
   n.stu.forEach(s=>{if(s.newpw){s.pwh=hash(String(s.newpw).slice(0,100));delete s.newpw}else s.pwh=old.get(s.id)});
   db=n;persist();return send(res,200,{rev:db.rev})}
  if(m==='POST'&&p==='/api/admin/password'){const b=await body(req,2e3);if(!check(b.o,db.adminPw)||str(b.n,100).length<6)return send(res,400,{});db.adminPw=hash(b.n);persist();return send(res,200,{ok:1})}}
 send(res,404,{})}
function serve(req,res,u){let p;try{p=decodeURIComponent(u.pathname)}catch(e){res.writeHead(400);return res.end()}
 if(p==='/')p='/index.html';const f=path.join(ROOT,path.normalize(p));if(!f.startsWith(ROOT+path.sep)){res.writeHead(403);return res.end()}
 fs.readFile(f,(e,d)=>{if(e){res.writeHead(404,{'Content-Type':'text/plain'});return res.end('Not found')}
  res.writeHead(200,{'Content-Type':MIME[path.extname(f).toLowerCase()]||'application/octet-stream','X-Content-Type-Options':'nosniff','X-Frame-Options':'SAMEORIGIN','Referrer-Policy':'same-origin','Cache-Control':'no-cache'});res.end(d)})}
init();
http.createServer((req,res)=>{const u=new URL(req.url,'http://localhost');
 if(u.pathname.startsWith('/api/'))api(req,res,u).catch(()=>{if(!res.headersSent)send(res,400,{})});else serve(req,res,u)}).listen(PORT,()=>console.log('Next Pro Institute running on http://localhost:'+PORT+'  ·  Made by ARS Cloud'));
