/* ARS Cloud — features & motion for Next Pro Institute
   Designed & developed by ARS Cloud · https://www.facebook.com/arscloudkst */
(function(){
var FB='https://www.facebook.com/arscloudkst';
var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches;
var d=document,$=function(s,r){return(r||d).querySelector(s)},$$=function(s,r){return[].slice.call((r||d).querySelectorAll(s))};
var isBn=function(){try{return localStorage.getItem('npi_lang')==='bn'}catch(e){return false}};
var tr=function(en,bn){return isBn()?bn:en};
var el=function(tag,cls,html){var e=d.createElement(tag);if(cls)e.className=cls;if(html!=null)e.innerHTML=html;return e};
/* bilingual helper: <span class="ax" data-en data-bn> re-translated on language toggle */
var ax=function(en,bn){return '<span class="ax" data-en="'+en.replace(/"/g,'&quot;')+'" data-bn="'+bn.replace(/"/g,'&quot;')+'">'+(isBn()?bn:en)+'</span>'};
function relang(){$$('.ax').forEach(function(e){e.textContent=isBn()?e.dataset.bn:e.dataset.en});
  var f=$('.ars-faq');if(f)f.placeholder=tr('Search questions…','প্রশ্ন খুঁজুন…');
  var th=$('#ars-th span');if(th)th.textContent=d.documentElement.dataset.theme==='dark'?tr('Light mode','লাইট মোড'):tr('Dark mode','ডার্ক মোড');
  quizDraw();calcDraw()}
var Lb=$('#lang');if(Lb)Lb.addEventListener('click',function(){setTimeout(relang,0)});

/* ---------- 0. theme (dark mode) ---------- */
try{if(localStorage.getItem('npi_theme')==='dark')d.documentElement.dataset.theme='dark'}catch(e){}

/* ---------- 1. preloader (once per session) ---------- */
var seen=false;try{seen=sessionStorage.getItem('ars_seen')==='1'}catch(e){}
if(!seen&&!rm){
 var L=el('div');L.id='ars-load';
 L.innerHTML='<div><div class="ring"><svg viewBox="0 0 100 100"><defs><linearGradient id="lg" x1="0" x2="1"><stop offset="0" stop-color="#FFB020"/><stop offset="1" stop-color="#FF3D77"/></linearGradient></defs><circle cx="50" cy="50" r="44" fill="none" stroke="rgba(255,255,255,.15)" stroke-width="6"/><circle cx="50" cy="50" r="44" fill="none" stroke="url(#lg)" stroke-width="6" stroke-linecap="round" stroke-dasharray="90 190"/></svg><i>☁️</i></div><b>ARS Cloud</b><small>Next Pro Institute</small><div class="bar"></div></div>';
 d.body.appendChild(L);
 var hide=function(){L.classList.add('done');setTimeout(function(){L.remove()},700);try{sessionStorage.setItem('ars_seen','1')}catch(e){}};
 setTimeout(hide,1250);
}

/* ---------- 2. hero: particle network, typewriter, floating chips ---------- */
var hero=$('.hero');
if(hero&&!rm){
 var cv=el('canvas');cv.id='ars-net';hero.insertBefore(cv,hero.firstChild);
 var cx=cv.getContext('2d'),W=0,H=0,P=[],mouse={x:-999,y:-999},run=true,dpr=Math.min(2,window.devicePixelRatio||1);
 function size(){W=hero.clientWidth;H=hero.clientHeight;cv.width=W*dpr;cv.height=H*dpr;cx.setTransform(dpr,0,0,dpr,0,0);
  var n=Math.max(22,Math.min(70,Math.round(W*H/16000)));P=[];for(var i=0;i<n;i++)P.push({x:Math.random()*W,y:Math.random()*H,vx:(Math.random()-.5)*.5,vy:(Math.random()-.5)*.5,r:Math.random()*2+1})}
 size();addEventListener('resize',size);
 hero.addEventListener('mousemove',function(e){var r=hero.getBoundingClientRect();mouse.x=e.clientX-r.left;mouse.y=e.clientY-r.top});
 hero.addEventListener('mouseleave',function(){mouse.x=mouse.y=-999});
 var going=false;
 function loop(){if(!run||d.hidden){going=false;if(run)setTimeout(loop,300);return}
  going=true;cx.clearRect(0,0,W,H);
  for(var i=0;i<P.length;i++){var a=P[i];a.x+=a.vx;a.y+=a.vy;if(a.x<0||a.x>W)a.vx*=-1;if(a.y<0||a.y>H)a.vy*=-1;
   var dx=a.x-mouse.x,dy=a.y-mouse.y,dm=Math.sqrt(dx*dx+dy*dy)||1;if(dm<130){a.x+=dx/dm*1.6;a.y+=dy/dm*1.6}
   cx.beginPath();cx.arc(a.x,a.y,a.r,0,6.283);cx.fillStyle='rgba(255,255,255,.75)';cx.fill();
   for(var j=i+1;j<P.length;j++){var b=P[j],ex=a.x-b.x,ey=a.y-b.y,ed=ex*ex+ey*ey;
    if(ed<12100){cx.strokeStyle='rgba(255,226,122,'+(.5*(1-ed/12100))+')';cx.lineWidth=1;cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(b.x,b.y);cx.stroke()}}
   if(dm<160){cx.strokeStyle='rgba(255,61,119,'+(.7*(1-dm/160))+')';cx.beginPath();cx.moveTo(a.x,a.y);cx.lineTo(mouse.x,mouse.y);cx.stroke()}}
  requestAnimationFrame(loop)}
 new IntersectionObserver(function(es){run=es[0].isIntersecting;if(run&&!going)loop()}).observe(hero);
 /* floating chips */
 [['📈 SEO','📈 এসইও'],['🤖 AI','🤖 এআই'],['🎬 Editing','🎬 এডিটিং'],['🎓 Certified','🎓 সার্টিফাইড']].forEach(function(c,i){
  var s=el('span','ars-chip c'+(i+1),ax(c[0],c[1]));hero.appendChild(s)});
}
/* typewriter (home only) */
var h1=$('.hero h1');
if(h1&&hero){
 var tw=el('div','ars-type','<span></span>');var pp=$('.hero .wrap p');if(pp)pp.parentNode.insertBefore(tw,pp);
 var tsp=tw.firstChild,WORDS=[['Digital Marketing','ডিজিটাল মার্কেটিং'],['Artificial Intelligence','আর্টিফিশিয়াল ইন্টেলিজেন্স'],['Professional Video Editing','প্রফেশনাল ভিডিও এডিটিং'],['a Verified Certificate','যাচাইযোগ্য সার্টিফিকেট']],wi=0,ci=0,del=false;
 if(rm){tsp.textContent=WORDS[0][isBn()?1:0]}else(function tick(){var w=WORDS[wi][isBn()?1:0];
  ci+=del?-1:1;tsp.textContent=w.slice(0,ci);var t=del?35:75;
  if(ci>w.length)ci=w.length;if(!del&&ci>=w.length){del=true;t=1500}else if(del&&ci<=0){ci=0;del=false;wi=(wi+1)%WORDS.length;t=350}
  setTimeout(tick,t)})();
 tw.insertAdjacentHTML('afterbegin','<em style="font-style:normal;opacity:.9">'+ax('Learn ','শিখুন ')+'</em>');
}

/* ---------- 3. Course finder quiz + savings calculator (home & courses) ---------- */
var COURSES={dm:{ic:'📈',n:['Digital Marketing','ডিজিটাল মার্কেটিং'],p:8000,u:'course-digital-marketing.html',m:3},
 ai:{ic:'🤖',n:['Artificial Intelligence','আর্টিফিশিয়াল ইন্টেলিজেন্স'],p:6000,u:'course-artificial-intelligence.html',m:2},
 ve:{ic:'🎬',n:['Professional Video Editing','প্রফেশনাল ভিডিও এডিটিং'],p:9000,u:'course-professional-video-editing.html',m:3},
 co:{ic:'🚀',n:['Combo Course','কম্বো কোর্স'],p:18000,u:'course-combo-course.html',m:6}};
var cn=function(k){return COURSES[k].n[isBn()?1:0]};
var money=function(n){return '৳ '+n.toLocaleString('en-IN')};
var QS=[
 {q:['What excites you the most?','কোন বিষয়টি আপনাকে সবচেয়ে বেশি আকর্ষণ করে?'],o:[
  [['Growing a business online','অনলাইনে ব্যবসা বড় করা'],{dm:3}],[['Using smart AI tools','স্মার্ট এআই টুল ব্যবহার'],{ai:3}],[['Creating videos & Reels','ভিডিও ও রিলস তৈরি'],{ve:3}],[['All of the above!','সবকিছুই!'],{co:3}]]},
 {q:['How much time can you give?','আপনি কতদিন সময় দিতে পারবেন?'],o:[
  [['About 2 months','প্রায় ২ মাস'],{ai:2}],[['About 3 months','প্রায় ৩ মাস'],{dm:1,ve:1}],[['6 months — I am serious','৬ মাস — আমি সিরিয়াস'],{co:3}]]},
 {q:['What is your main goal?','আপনার মূল লক্ষ্য কী?'],o:[
  [['Freelancing / client work','ফ্রিল্যান্সিং / ক্লায়েন্ট কাজ'],{dm:1,ve:2}],[['Work smarter in my job or study','চাকরি/পড়াশোনায় দক্ষতা বাড়ানো'],{ai:2}],[['Start my own agency or brand','নিজের এজেন্সি বা ব্র্যান্ড'],{co:2,dm:1}]]}];
var qs={i:0,sc:{dm:0,ai:0,ve:0,co:0},done:false},kSel={dm:1,ai:1,ve:0};
var qBox,cBox;
function quizDraw(){if(!qBox)return;
 if(qs.done){var best='dm';Object.keys(qs.sc).forEach(function(k){if(qs.sc[k]>qs.sc[best])best=k});var c=COURSES[best];
  qBox.innerHTML='<div class="q-res"><span class="big">'+c.ic+'</span><small>'+ax('Your best match','আপনার জন্য সেরা')+'</small><h3>'+cn(best)+'</h3><p>'+c.m+' '+ax('months','মাস')+' · '+money(c.p)+'</p><a class="btn" href="'+c.u+'">'+ax('View details','বিস্তারিত দেখুন')+'</a><a class="btn outline" href="apply.html">'+ax('Apply Now','ভর্তি হন')+'</a><br><button class="q-reset" type="button">'+ax('Retake quiz','আবার চেষ্টা করুন')+'</button></div>';
  $('.q-reset',qBox).onclick=function(){qs={i:0,sc:{dm:0,ai:0,ve:0,co:0},done:false};quizDraw()};return}
 var Q=QS[qs.i];
 qBox.innerHTML='<div class="q-prog"><i style="width:'+(qs.i/QS.length*100)+'%"></i></div><div class="q-q">'+(qs.i+1)+'/'+QS.length+' · '+Q.q[isBn()?1:0]+'</div>'+Q.o.map(function(o,i){return '<button type="button" class="q-opt" data-i="'+i+'">'+o[0][isBn()?1:0]+'</button>'}).join('');
 requestAnimationFrame(function(){var b=$('.q-prog i',qBox);if(b)b.style.width=((qs.i+.001)/QS.length*100)+'%'});
 $$('.q-opt',qBox).forEach(function(b){b.onclick=function(){var pts=Q.o[+b.dataset.i][1];for(var k in pts)qs.sc[k]+=pts[k];qs.i++;if(qs.i>=QS.length)qs.done=true;quizDraw()}})}
function countTo(node,to){var from=+node.dataset.v||0;node.dataset.v=to;if(rm){node.textContent=money(to);return}var t0=performance.now();(function f(t){var p=Math.min(1,(t-t0)/600),e=1-Math.pow(1-p,3);node.textContent=money(Math.round(from+(to-from)*e));if(p<1)requestAnimationFrame(f)})(t0)}
function calcDraw(){if(!cBox)return;var keys=['dm','ai','ve'];
 var sum=0;keys.forEach(function(k){if(kSel[k])sum+=COURSES[k].p});
 var all=keys.every(function(k){return kSel[k]});var pay=all?COURSES.co.p:sum,save=all?sum-COURSES.co.p:0;
 var prev=$('.k-tot b',cBox),pv=prev?prev.dataset.v:0;
 cBox.innerHTML=keys.map(function(k){return '<div class="k-row'+(kSel[k]?' on':'')+'" data-k="'+k+'" role="checkbox" tabindex="0" aria-checked="'+(!!kSel[k])+'"><span class="ck">✓</span><span class="nm">'+COURSES[k].ic+' '+cn(k)+'</span><span class="pr">'+money(COURSES[k].p)+'</span></div>'}).join('')+
  '<div class="k-tot"><small>'+ax(all?'Combo Course price':'Total fee','ফি')+'</small><b data-v="'+(pv||0)+'">'+money(pay)+'</b>'+(save>0?'<span class="k-save">🎉 '+ax('You save','আপনি বাঁচাবেন')+' '+money(save)+'</span>':'<small style="margin-top:6px">'+ax('Select all 3 to unlock the Combo saving','কম্বো সাশ্রয় পেতে ৩টিই নির্বাচন করুন')+'</small>')+'</div>'+
  '<p style="text-align:center;margin:14px 0 0"><a class="btn sm" href="apply.html">'+ax('Apply Now','ভর্তি হন')+'</a></p>';
 var b=$('.k-tot b',cBox);if(b){b.textContent=money(pv?+pv:0);countTo(b,pay)}
 $$('.k-row',cBox).forEach(function(r){var tg=function(){kSel[r.dataset.k]=kSel[r.dataset.k]?0:1;calcDraw()};r.onclick=tg;r.onkeydown=function(e){if(e.key===' '||e.key==='Enter'){e.preventDefault();tg()}}})}
function buildTools(){
 var sec=el('section','alt ars-sec');
 sec.innerHTML='<span class="ars-aurora" style="width:320px;height:320px;left:-80px;top:-60px;background:#8B2FD6"></span><span class="ars-aurora" style="width:280px;height:280px;right:-60px;bottom:-60px;background:#FFB020;animation-delay:-4s"></span>'+
  '<div class="wrap"><span class="ars-kicker">'+ax('Smart tools','স্মার্ট টুলস')+'</span><h2>'+ax('Find your perfect course','আপনার সেরা কোর্স খুঁজুন')+'</h2><p class="ars-sub">'+ax('Answer 3 quick questions, then see how much you can save with the Combo Course.','৩টি ছোট প্রশ্নের উত্তর দিন, তারপর কম্বো কোর্সে কত সাশ্রয় হয় দেখুন।')+'</p>'+
  '<div class="ars-two"><div class="ars-box"><h3>🧭 '+ax('Course Finder','কোর্স ফাইন্ডার')+'</h3><div id="ars-quiz"></div></div><div class="ars-box"><h3>💰 '+ax('Fee & Savings Calculator','ফি ও সাশ্রয় ক্যালকুলেটর')+'</h3><div id="ars-calc"></div></div></div></div>';
 return sec}
var page=location.pathname.split('/').pop()||'index.html';
if(page==='' || page==='index.html' || page==='courses.html'){
 var main=$('main'),sec=buildTools();
 if(page==='courses.html'){main.appendChild(sec)}else{var bo=$('.boost');if(bo)main.insertBefore(sec,bo);else main.appendChild(sec)}
 qBox=$('#ars-quiz',sec);cBox=$('#ars-calc',sec);quizDraw();calcDraw();
 /* reveal on scroll */
 if('IntersectionObserver' in window&&!rm){$$('.ars-box',sec).forEach(function(b,i){b.style.opacity=0;b.style.transform='translateY(40px) scale(.96)';b.style.transition='all .8s '+(i*.15)+'s cubic-bezier(.2,.8,.2,1)'});
  var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){$$('.ars-box',sec).forEach(function(b){b.style.opacity=1;b.style.transform='none'});io.disconnect()}})},{threshold:.15});io.observe(sec)}
}

/* ---------- 4. FAQ live search ---------- */
var fq=$$('details');
if(fq.length>=3&&$('main')){
 var holder=fq[0].parentNode;var inp=el('input','ars-faq');inp.type='search';inp.placeholder=tr('Search questions…','প্রশ্ন খুঁজুন…');inp.setAttribute('aria-label','Search FAQ');holder.insertBefore(inp,fq[0]);
 inp.addEventListener('input',function(){var q=inp.value.trim().toLowerCase();fq.forEach(function(x){x.hidden=q&&x.textContent.toLowerCase().indexOf(q)<0})});
}

/* ---------- 5. speed dial + dark mode ---------- */
var dial=el('div');dial.id='ars-dial';
dial.innerHTML='<a class="it" href="apply.html"><span>'+ax('Apply Now','ভর্তি হন')+'</span><i>📝</i></a><a class="it" href="contact.html"><span>'+ax('Contact','যোগাযোগ')+'</span><i>💬</i></a><button class="it" id="ars-th" type="button"><span></span><i>🌙</i></button><button class="main" type="button" aria-label="Quick actions" aria-expanded="false">✦</button>';
d.body.appendChild(dial);
var mb=$('.main',dial);mb.onclick=function(e){e.stopPropagation();var o=dial.classList.toggle('open');mb.setAttribute('aria-expanded',o)};
d.addEventListener('click',function(e){if(!dial.contains(e.target))dial.classList.remove('open')});
$('#ars-th').onclick=function(){var dk=d.documentElement.dataset.theme==='dark';if(dk)delete d.documentElement.dataset.theme;else d.documentElement.dataset.theme='dark';try{localStorage.setItem('npi_theme',dk?'light':'dark')}catch(e){}$('#ars-th i').textContent=dk?'🌙':'☀️';relang()};
if(d.documentElement.dataset.theme==='dark')$('#ars-th i').textContent='☀️';

/* ---------- 6. back-to-top with progress ring ---------- */
var tp=el('button');tp.id='ars-top';tp.type='button';tp.setAttribute('aria-label','Back to top');
tp.innerHTML='<svg viewBox="0 0 52 52"><defs><linearGradient id="arsGrad" x1="0" x2="1"><stop offset="0" stop-color="#FFB020"/><stop offset="1" stop-color="#FF3D77"/></linearGradient></defs><circle class="bg" cx="26" cy="26" r="23"/><circle class="fg" cx="26" cy="26" r="23"/></svg>↑';
d.body.appendChild(tp);tp.onclick=function(){scrollTo({top:0,behavior:rm?'auto':'smooth'})};
var fg=$('.fg',tp),bar=null;
/* ---------- 7. sticky apply bar on course pages ---------- */
if(/^course-/.test(page)){
 var ap=$$('a[href^="apply.html"]')[0],ttl=$('h1');
 bar=el('div');bar.id='ars-bar';bar.innerHTML='<div class="wrap"><div><b>'+(ttl?ttl.textContent:'')+'</b><small>'+ax('Seats are limited — secure yours today','আসন সীমিত — আজই নিশ্চিত করুন')+'</small></div><a class="btn" href="'+(ap?ap.getAttribute('href'):'apply.html')+'">'+ax('Apply Now','ভর্তি হন')+'</a></div>';d.body.appendChild(bar);d.body.classList.add('ars-has-bar')}
function onScroll(){var h=d.documentElement,m=h.scrollHeight-h.clientHeight,p=m>0?h.scrollTop/m:0;
 fg.style.strokeDashoffset=144.5*(1-p);tp.classList.toggle('show',h.scrollTop>400);if(bar)bar.classList.toggle('show',h.scrollTop>520&&p<.94)}
addEventListener('scroll',onScroll,{passive:true});onScroll();

/* ---------- 8. button ripple ---------- */
d.addEventListener('click',function(e){var b=e.target.closest&&e.target.closest('.btn');if(!b||rm)return;
 var r=b.getBoundingClientRect(),s=Math.max(r.width,r.height),sp=el('span','ars-rip');
 sp.style.cssText='width:'+s+'px;height:'+s+'px;left:'+(e.clientX-r.left-s/2)+'px;top:'+(e.clientY-r.top-s/2)+'px';
 b.appendChild(sp);setTimeout(function(){sp.remove()},700)});

/* ---------- 9. ARS Cloud credit (footer) ---------- */
var ft=$('.site-footer .wrap');
if(ft){
 var cp=$('.copy',ft),cr=el('div','ars-credit');
 cr.innerHTML='<svg class="cl" viewBox="0 0 64 64" aria-hidden="true"><defs><linearGradient id="cg2" x1="0" x2="1" y1="0" y2="1"><stop offset="0" stop-color="#FFB020"/><stop offset=".5" stop-color="#FF3D77"/><stop offset="1" stop-color="#2E90FA"/></linearGradient></defs><path d="M20 50a13 13 0 0 1-2-25.8A16 16 0 0 1 49 22a14 14 0 0 1-2 28z" fill="url(#cg2)"/><path d="M26 36l6 6 10-12" fill="none" stroke="#fff" stroke-width="4" stroke-linecap="round" stroke-linejoin="round"/></svg>'+
  '<div class="tx"><small>'+ax('Website designed & developed by','ওয়েবসাইট ডিজাইন ও ডেভেলপমেন্ট')+'</small><strong>ARS Cloud</strong><span>'+ax('Websites · Cloud · Digital solutions','ওয়েবসাইট · ক্লাউড · ডিজিটাল সলিউশন')+'</span></div>'+
  '<a class="btn sm" href="'+FB+'" target="_blank" rel="noopener">'+ax('Visit ARS Cloud','ARS Cloud ভিজিট করুন')+' ↗</a>';
 ft.insertBefore(cr,cp);
 var ar=$('.ars',ft);if(ar)ar.innerHTML='Made by <a class="ars-link" href="'+FB+'" target="_blank" rel="noopener">ARS Cloud</a>';
}
/* signature */
try{console.log('%c☁ ARS Cloud %c— designed & developed by ARS Cloud · '+FB,'background:linear-gradient(90deg,#FFB020,#FF3D77);color:#1B1464;padding:4px 8px;border-radius:4px;font-weight:700','color:#8B2FD6')}catch(e){}
relang();
})();
