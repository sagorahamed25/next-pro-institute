(function(){
var $=function(i){return document.getElementById(i)},esc=function(s){return String(s==null?'':s).replace(/[&<>"']/g,function(c){return{'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]})},PD=null,rerender=function(){};
/* thanks page: contact variant */
if(new URLSearchParams(location.search).get('f')==='contact'){var tx=document.querySelector('.card .t');if(tx){tx.innerHTML='Thank you! Your message has been received. The institute will reply soon.';tx.dataset.bn='ধন্যবাদ! আপনার বার্তা গ্রহণ করা হয়েছে। প্রতিষ্ঠান শীঘ্রই উত্তর দেবে।'}}
/* language toggle */
var els=[].slice.call(document.querySelectorAll('.t'));els.forEach(function(e){e._en=e.innerHTML});
var bn=false;try{bn=localStorage.getItem('npi_lang')==='bn'}catch(e){}
var L=$('lang');
function apply(){els.forEach(function(e){e.innerHTML=bn?e.dataset.bn:e._en});document.documentElement.lang=bn?'bn':'en';L.textContent=bn?'EN':'বাংলা';try{localStorage.setItem('npi_lang',bn?'bn':'en')}catch(e){}rerender()}
L.onclick=function(ev){ev.preventDefault();bn=!bn;apply()};apply();
var T=function(a,b){return bn?b:a};
/* active nav link */
var cur=location.pathname.split('/').pop()||'index.html';
[].slice.call(document.querySelectorAll('.nav a')).forEach(function(a){var h=a.getAttribute('href');if(h===cur||(cur.indexOf('course-')===0&&h==='courses.html'))a.classList.add('active')});
/* scroll reveal */
var rv=[].slice.call(document.querySelectorAll('.card,.step,details,.cta,.form-card,.result,section h2,.boost .wrap'));
if('IntersectionObserver' in window){var io=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io.unobserve(x.target)}})},{threshold:.12});
 rv.forEach(function(e,i){e.classList.add('rv');e.style.transitionDelay=(i%4)*80+'ms';io.observe(e)})}
/* apply form: preselect course */
var c=$('course');if(c){var q=new URLSearchParams(location.search).get('course');if(q)c.value=q}
/* apply + contact forms -> server */
[].forEach.call(document.querySelectorAll('form[name=apply],form[name=contact]'),function(f){f.addEventListener('submit',function(ev){ev.preventDefault();
 var o={};new FormData(f).forEach(function(v,k){o[k]=v});o.consent=f.elements.consent?f.elements.consent.checked:true;o.consent_public=f.elements.consent_public?f.elements.consent_public.checked:false;
 var b=f.querySelector('button[type=submit]');b.disabled=true;
 fetch('/api/'+f.name,{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify(o)}).then(function(r){if(!r.ok)throw 0;location.href='thanks.html?f='+f.name}).catch(function(){b.disabled=false;alert(T('Could not send. Please try again.','পাঠানো যায়নি। আবার চেষ্টা করুন।'))})})});
/* certificate verification */
var vf=$('vform');
if(vf){vf.onsubmit=function(ev){ev.preventDefault();var o=$('vout');
 var S={valid:['Valid','বৈধ','This certificate was issued by Next Pro Institute and is currently valid.','এই সার্টিফিকেটটি Next Pro Institute থেকে ইস্যু করা হয়েছে এবং বর্তমানে বৈধ।'],suspended:['Suspended','স্থগিত','This certificate is temporarily suspended. Please contact the institute.','এই সার্টিফিকেটটি সাময়িকভাবে স্থগিত। প্রতিষ্ঠানের সাথে যোগাযোগ করুন।'],revoked:['Revoked','বাতিল','This certificate has been revoked by the institute.','প্রতিষ্ঠান এই সার্টিফিকেটটি বাতিল করেছে।']};
 fetch('/api/verify?c='+encodeURIComponent($('vc').value)+'&r='+encodeURIComponent($('vr').value)).then(function(r){return r.json()}).then(function(r){var s=r.found&&S[r.status];
  if(s)o.innerHTML='<div class="result in"><div class="banner '+r.status+'">'+(r.status==='valid'?'✓ ':'! ')+(bn?s[1]:s[0])+'</div><p style="padding:14px 24px 0;margin:0">'+(bn?s[3]:s[2])+'</p><dl><dt>Certificate No.</dt><dd>'+esc(r.no)+'</dd><dt>Registration No.</dt><dd>'+esc(r.reg)+'</dd><dt>Course</dt><dd>'+esc(r.course)+'</dd>'+(r.name?'<dt>Name</dt><dd>'+esc(r.name)+'</dd>':'')+'</dl></div>';
  else o.innerHTML='<div class="result in"><div class="banner notfound">✕ '+T('Not verified','যাচাই করা যায়নি')+'</div><p style="padding:14px 24px">'+T('We could not verify a certificate with these details. Please check both numbers and try again.','এই তথ্য দিয়ে কোনো সার্টিফিকেট যাচাই করা যায়নি। অনুগ্রহ করে দুটি নম্বর আবার দেখে চেষ্টা করুন।')+'</p></div>'}).catch(function(){o.innerHTML='<p class="err">'+T('Server not reachable.','সার্ভারে সংযোগ করা যায়নি।')+'</p>'})}}
/* public info: contact details + instructors managed from admin */
if($('cinfo')||document.querySelector('.avatar')){fetch('/api/public').then(function(r){return r.json()}).then(function(d){
 var i=d.info||{},ci=$('cinfo');
 if(ci){var h=[];if(i.phone)h.push('📞 <a href="tel:'+esc(i.phone.replace(/[^0-9+]/g,''))+'">'+esc(i.phone)+'</a>');if(i.email)h.push('✉️ <a href="mailto:'+esc(i.email)+'">'+esc(i.email)+'</a>');
  if(i.whatsapp)h.push('💬 WhatsApp: <a href="https://wa.me/'+esc(i.whatsapp.replace(/[^0-9]/g,''))+'" target="_blank" rel="noopener">'+esc(i.whatsapp)+'</a>');
  if(/^https?:\/\//i.test(i.facebook||''))h.push('👍 <a href="'+esc(i.facebook)+'" target="_blank" rel="noopener">Facebook</a>');if(i.address)h.push('📍 '+esc(i.address));
  if(h.length){ci.innerHTML=h.join('<br>');ci.hidden=false;ci.style.marginBottom='18px'}}
 var av=document.querySelector('.avatar');
 if(av&&d.ins&&d.ins.length){var grid=av.closest('.card').parentNode;grid.innerHTML=d.ins.map(function(x){return '<div class="card gold" style="text-align:center"><div class="avatar">'+esc((x.n||'?').charAt(0).toUpperCase())+'</div><h3>'+esc(x.n)+'</h3><div class="eyebrow">'+esc(x.role)+'</div><p>'+String(x.sk||'').split(',').filter(function(s){return s.trim()}).map(function(s){return '<span class="pill" style="margin:2px">'+esc(s.trim())+'</span>'}).join('')+'</p>'+(x.bio?'<p style="font-size:.9rem">'+esc(x.bio)+'</p>':'')+'</div>'}).join('')}}).catch(function(){})}
/* student portal */
var login=$('plogin'),dash=$('pdash');
if(login&&dash){var TK='npi_st',tk=function(){try{return sessionStorage.getItem(TK)||''}catch(e){return ''}};
 var money=function(n){return '৳ '+Number(n).toLocaleString('en-US')};
 var when=function(s){var d=new Date(s);return isNaN(d)?esc(s):d.toLocaleString(bn?'bn-BD':'en-GB',{day:'numeric',month:'short',hour:'numeric',minute:'2-digit'})};
 var row=function(c){return '<tr><td>'+when(c.at)+'</td><td>'+esc(c.title)+(c.note?'<br><small>'+esc(c.note)+'</small>':'')+'</td><td>'+(c.url?'<a class="btn sm" href="'+esc(c.url)+'" target="_blank" rel="noopener">'+T('Join class','ক্লাসে যোগ দিন')+'</a>':'—')+'</td></tr>'};
 var empty=function(a,b){return '<p class="notice">'+T(a,b)+'</p>'};
 function out(){try{sessionStorage.removeItem(TK)}catch(e){}PD=null;login.hidden=false;dash.hidden=true}
 function render(d){PD=d;var s=d.st,now=Date.now()-72e5,up=[],ps=[];d.classes.forEach(function(c){(new Date(c.at).getTime()>=now?up:ps).push(c)});
  up.sort(function(a,b){return new Date(a.at)-new Date(b.at)});ps.sort(function(a,b){return new Date(b.at)-new Date(a.at)});
  $('pav').textContent=(s.n||'?').charAt(0).toUpperCase();$('pname').textContent=T('Welcome, ','স্বাগতম, ')+s.n;$('pid').textContent=s.r+' · ID: '+s.id;
  var due=d.pay?d.pay.fee-d.pay.paid:0;
  $('pstats').innerHTML=[[s.c,T('My course','আমার কোর্স')],[up.length,T('Upcoming classes','আসন্ন ক্লাস')],[money(due),T('Fee due','বকেয়া ফি')]].map(function(x){return '<div class="card gold"><div class="stat" style="font-size:1.5rem">'+esc(x[0])+'</div><div>'+x[1]+'</div></div>'}).join('');
  var th='<table><tr><th>'+T('When','সময়')+'</th><th>'+T('Class','ক্লাস')+'</th><th></th></tr>',none=empty('No class links yet. Your instructor will add them here.','এখনো কোনো ক্লাসের লিংক নেই। প্রশিক্ষক এখানে যোগ করবেন।');
  $('pnext').innerHTML=up.length?th+up.slice(0,5).map(row).join('')+'</table>':none;
  $('pall').innerHTML=(up.length||ps.length)?th+up.concat(ps).map(row).join('')+'</table>':none;
  var P=[[T('Full name','পূর্ণ নাম'),s.n],[T('Registration No.','রেজিস্ট্রেশন নম্বর'),s.r+' 🔒'],[T('Student ID','স্টুডেন্ট আইডি'),s.id+' 🔒'],[T('Phone','ফোন'),s.ph],['Email',s.email],[T('Course','কোর্স'),s.c],[T('Admission date','ভর্তির তারিখ'),s.d]].filter(function(r){return r[1]});
  $('pprof').innerHTML='<table>'+P.map(function(r){return '<tr><th style="width:38%">'+r[0]+'</th><td>'+esc(r[1])+'</td></tr>'}).join('')+'</table>';
  var py=d.pay,pc=py&&py.fee?Math.round(py.paid/py.fee*100):0;
  $('ppay').innerHTML=py?'<div class="card"><table><tr><th>'+T('Total fee','মোট ফি')+'</th><td>'+money(py.fee)+'</td></tr><tr><th>'+T('Paid','পরিশোধিত')+'</th><td>'+money(py.paid)+'</td></tr><tr><th>'+T('Due','বকেয়া')+'</th><td><b>'+money(due)+'</b></td></tr></table><div class="bar"><i style="width:'+pc+'%"></i></div><small>'+pc+'%</small></div>':empty('No payment record yet.','এখনো কোনো পেমেন্ট রেকর্ড নেই।');
  $('pcert').innerHTML=d.certs.length?'<table><tr><th>'+T('Certificate No.','সার্টিফিকেট নম্বর')+'</th><th>'+T('Course','কোর্স')+'</th><th>'+T('Status','অবস্থা')+'</th></tr>'+d.certs.map(function(x){return '<tr><td>'+esc(x.no)+'</td><td>'+esc(x.c)+'</td><td><span class="pill '+esc(x.s)+'">'+esc(x.s)+'</span></td></tr>'}).join('')+'</table>':empty('No certificate issued yet.','এখনো কোনো সার্টিফিকেট ইস্যু হয়নি।')}
 rerender=function(){if(PD)render(PD)};
 function loadMe(){fetch('/api/student/me',{headers:{Authorization:'Bearer '+tk()}}).then(function(r){if(r.status===401)throw 0;return r.json()}).then(function(d){login.hidden=true;dash.hidden=false;render(d);window.scrollTo(0,0)}).catch(out)}
 $('pform').addEventListener('submit',function(ev){ev.preventDefault();var er=$('perr');er.hidden=true;
  fetch('/api/student/login',{method:'POST',headers:{'Content-Type':'application/json'},body:JSON.stringify({reg:$('preg').value,pw:$('ppw').value})}).then(function(r){return r.json().then(function(j){return[r.status,j]})}).then(function(x){if(x[1].token){try{sessionStorage.setItem(TK,x[1].token)}catch(e){}$('pform').reset();loadMe()}else{er.hidden=false}}).catch(function(){er.hidden=false})});
 $('plogout').onclick=out;
 var tabs=[].slice.call(dash.querySelectorAll('.ptabs button')),panes=[].slice.call(dash.querySelectorAll('.ptab'));
 tabs.forEach(function(b){b.onclick=function(){tabs.forEach(function(x){x.classList.toggle('on',x===b)});panes.forEach(function(p){p.hidden=p.dataset.tab!==b.dataset.tab})}});
 $('corr').addEventListener('submit',function(ev){ev.preventDefault();var t=$('corrt').value;
  fetch('/api/student/correction',{method:'POST',headers:{'Content-Type':'application/json',Authorization:'Bearer '+tk()},body:JSON.stringify({text:t})}).then(function(r){if(!r.ok)throw 0;$('corrok').hidden=false;$('corr').reset()}).catch(function(){alert(T('Could not send.','পাঠানো যায়নি।'))})});
 if(tk())loadMe()}
})();
