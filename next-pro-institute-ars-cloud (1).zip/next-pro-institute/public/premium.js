(function(){
var rm=window.matchMedia&&matchMedia('(prefers-reduced-motion:reduce)').matches,fine=window.matchMedia&&matchMedia('(hover:hover)').matches;
document.body.classList.add('pm-ready');
/* progress bar + header shrink */
var sp=document.createElement('div');sp.id='sp';document.body.appendChild(sp);
var hd=document.querySelector('.site-header');
function sc(){var h=document.documentElement,m=h.scrollHeight-h.clientHeight;sp.style.width=(m>0?h.scrollTop/m*100:0)+'%';if(hd)hd.classList.toggle('shrunk',h.scrollTop>30)}
addEventListener('scroll',sc,{passive:true});sc();
/* page transition */
[].forEach.call(document.querySelectorAll('a[href$=".html"]'),function(a){a.addEventListener('click',function(e){if(e.metaKey||e.ctrlKey||a.target||rm)return;e.preventDefault();document.body.classList.add('leaving');setTimeout(function(){location.href=a.href},300)})});
addEventListener('pageshow',function(){document.body.classList.remove('leaving')});
/* footer admin link */
var fl=document.querySelector('.site-footer .grid>div:nth-child(2)');if(fl){var ad=document.createElement('a');ad.href='admin.html';ad.className='pm-admin';ad.textContent='Admin';fl.appendChild(ad)}
if(rm)return;
/* split hero headline into words */
var h1=document.querySelector('.hero h1');
if(h1){var d=0;(function walk(n){[].slice.call(n.childNodes).forEach(function(c){if(c.nodeType===3){var f=document.createDocumentFragment();c.textContent.split(/(\s+)/).forEach(function(w){if(!w)return;if(/^\s+$/.test(w)){f.appendChild(document.createTextNode(' '));return}var s=document.createElement('span');s.className='word';var i=document.createElement('i');i.textContent=w;i.style.animationDelay=(.15+d++*.09)+'s';s.appendChild(i);f.appendChild(s)});n.replaceChild(f,c)}else if(c.nodeType===1)walk(c)})})(h1)}
/* hero spotlight + blob parallax + scroll cue */
var hero=document.querySelector('.hero');
if(hero){var cue=document.createElement('div');cue.className='scrollcue';hero.appendChild(cue);
 var bl=[].slice.call(hero.querySelectorAll('.blob'));
 hero.addEventListener('mousemove',function(e){var r=hero.getBoundingClientRect(),x=e.clientX-r.left,y=e.clientY-r.top;hero.style.setProperty('--mx',x+'px');hero.style.setProperty('--my',y+'px');
  bl.forEach(function(b,i){var k=(i+1)*9;b.style.translate=((x/r.width-.5)*k)+'px '+((y/r.height-.5)*k)+'px'})})}
/* cursor glow */
if(fine){var cg=document.createElement('div');cg.id='cg';document.body.appendChild(cg);
 addEventListener('mousemove',function(e){cg.style.transform='translate('+e.clientX+'px,'+e.clientY+'px)'},{passive:true})}
/* tilt + glare on cards, magnetic buttons */
if(fine){
 [].forEach.call(document.querySelectorAll('.card'),function(c){c.classList.add('tilt');
  c.addEventListener('mousemove',function(e){var r=c.getBoundingClientRect(),px=(e.clientX-r.left)/r.width,py=(e.clientY-r.top)/r.height;
   c.style.transform='perspective(800px) rotateX('+((.5-py)*8)+'deg) rotateY('+((px-.5)*10)+'deg) translateY(-6px)';c.style.setProperty('--gx',px*100+'%');c.style.setProperty('--gy',py*100+'%')});
  c.addEventListener('mouseleave',function(){c.style.transform=''})});
 [].forEach.call(document.querySelectorAll('.btn'),function(b){b.classList.add('mag');
  b.addEventListener('mousemove',function(e){var r=b.getBoundingClientRect();b.style.transform='translate('+((e.clientX-r.left-r.width/2)*.22)+'px,'+((e.clientY-r.top-r.height/2)*.3-3)+'px)'});
  b.addEventListener('mouseleave',function(){b.style.transform=''})})}
/* stats band on home */
var mq=document.querySelector('.marquee');
if(mq&&document.querySelector('.hero')){var s=document.createElement('section');s.className='pm-stats';
 var D=[[4,'','Courses'],[6,'','Steps to Certificate'],[100,'%','Hands-on Focus'],[24,'/7','Online Verification']];
 s.innerHTML='<div class="wrap"><div class="grid">'+D.map(function(x){return '<div class="it"><b data-n="'+x[0]+'" data-s="'+x[1]+'">0'+x[1]+'</b><span>'+x[2]+'</span></div>'}).join('')+'</div></div>';
 mq.parentNode.insertBefore(s,mq.nextSibling);
 var io2=new IntersectionObserver(function(es){es.forEach(function(x){if(!x.isIntersecting)return;io2.unobserve(x.target);
  [].forEach.call(x.target.querySelectorAll('b'),function(b){var n=+b.dataset.n,t0=performance.now();(function f(t){var p=Math.min(1,(t-t0)/1400),e=1-Math.pow(1-p,3);b.textContent=Math.round(n*e)+b.dataset.s;if(p<1)requestAnimationFrame(f)})(t0)})})},{threshold:.4});io2.observe(s)}
/* reveal extras (headings underline, steps) */
var io3=new IntersectionObserver(function(es){es.forEach(function(x){if(x.isIntersecting){x.target.classList.add('in');io3.unobserve(x.target)}})},{threshold:.2});
[].forEach.call(document.querySelectorAll('.step'),function(e,i){e.style.transitionDelay=i*110+'ms';e.style.transition='opacity .6s,transform .6s cubic-bezier(.2,.8,.2,1.4)';io3.observe(e)});
})();
