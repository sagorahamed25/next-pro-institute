# Next Pro Institute — website + admin panel
Made by ARS Cloud

## Run
    node server.js          # Node 18+, no npm install needed
Open http://localhost:3000 — admin panel: /admin.html

First start prints the admin password in the terminal (user `admin`). You can set your own:
    ADMIN_PASSWORD=YourStrongPass node server.js     # only used on first start (when data/ is empty)
Change it later in Admin → Settings.

## What goes where
- Website admission form → Admin → Applications (approve = student account + login created)
- Website contact form + student correction requests → Admin → Messages
- Admin → Class links → shown on the student's portal dashboard (all students / one course / one student)
- All data is stored in `data/db.json` (back this folder up!)

## Deploy
Any host that runs Node (VPS, Render, Railway, etc.) with a persistent disk for `data/`.
Put HTTPS in front (Nginx/Caddy/host SSL) and set `TRUST_PROXY=1` if behind a proxy. Env: PORT, ADMIN_PASSWORD, TRUST_PROXY.

## ARS Cloud feature layer (public/ars.css + public/ars.js)
Designed & developed by ARS Cloud — https://www.facebook.com/arscloudkst
Loaded on every public page (EN/বাংলা aware, respects reduced-motion):
- Animated ARS Cloud preloader (once per session)
- Hero: interactive particle network, typewriter headline, floating course chips
- Course Finder quiz + Fee & Combo Savings calculator (Home & Courses pages)
- FAQ live search, animated accordion
- Quick-action speed dial (Apply / Contact / Dark mode), dark mode (remembered)
- Back-to-top button with scroll-progress ring
- Sticky "Apply Now" bar on course pages
- Button ripple effect
- Animated ARS Cloud credit card in the footer linking to the ARS Cloud Facebook page
To remove the layer: delete the ars.css / ars.js lines from the HTML files.
